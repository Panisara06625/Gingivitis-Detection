# gingivitis > 2024-06-09 6:24pm
https://universe.roboflow.com/1sep208panisara-triamrangsee/gingivitis-dyrjr

Provided by a Roboflow user
License: CC BY 4.0

